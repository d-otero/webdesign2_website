
activeElement = $(location.hash);
debug = true;

// ScrollReveal().reveal(activeElement, {
//     delay: 150,
// })

// ScrollReveal().reveal(activeChildren, {
//     delay: 200,
//     reset: true
// });

// loadMore(activeChildren).then(function () {
//     ScrollReveal().sync();
// });

