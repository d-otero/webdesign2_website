document.addEventListener('DOMContentLoaded', function () {
  setTimeout(function() {
    $('#overlay').toggle('600');
  });
});
