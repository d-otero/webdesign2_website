// blahContainer.innerHTML = caseStudyConstructor(cases[0]);
// cunyfirstContainer.innerHTML = caseStudyConstructor(cases[1]);
// salvationArmyContainer.innerHTML = csVisualConstructor(visual[0]);
// safeSexContainer.innerHTML = csVisualConstructor(visual[1]);
// gladwellContainer.innerHTML = csVisualConstructor(visual[2]);

// contentContainer.innerHTML = cunyfirstContainer;
